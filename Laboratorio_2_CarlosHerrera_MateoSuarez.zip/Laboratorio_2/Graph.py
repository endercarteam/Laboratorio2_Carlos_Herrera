from Nodo import Nodo
from Grafo import Grafo
n = 0

class Graph:
    def __init__(self):
        self.nodes = []
    
    def add_node(self, node):
        self.nodes.append(node)
    
    def remove_node(self, node):
        self.nodes.remove(node)
        for n in self.nodes:
            if node in n.edges:
                n.remove_edge(node)
    
    def draw(self, canvas):
        
        for node in self.nodes:
            for neighbor, weight in node.edges.items():
                canvas.create_line(node.x, node.y, neighbor.x, neighbor.y)
                canvas.create_text((node.x + neighbor.x) / 2, (node.y + neighbor.y) / 2, text=weight)
            canvas.create_oval(node.x-10, node.y-10, node.x+10, node.y+10, fill='white')
            canvas.create_text(node.x, node.y, text=str(self.nodes.index(node)))


    def add_nodes(self):
        n = 0
        for self.node in self.nodes:
            nodo = Nodo(n)   
            Grafo.agregar_nodo(nodo)
            n = n + 1         
