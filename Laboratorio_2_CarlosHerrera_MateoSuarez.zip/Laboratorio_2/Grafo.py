
class Grafo:
    def __init__(self):
        self.nodos = []
        self.aristas = []

    def agregar_nodo(self, nodo):
        if nodo not in self.nodos:
            self.nodos.append(nodo)

    def agregar_arista(self, arista):
        if arista not in self.aristas:
            self.aristas.append(arista)

    def obtener_matriz_pesos(self):
        n = len(self.nodos)
        matriz_pesos = [[float("inf") for _ in range(n)] for _ in range(n)]

        for i in range(n):
            matriz_pesos[i][i] = 0

        for arista in self.aristas:
            inicio = self.nodos.index(arista.obtener_inicio())
            fin = self.nodos.index(arista.obtener_fin())
            peso = arista.obtener_peso()
            matriz_pesos[inicio][fin] = peso

        return matriz_pesos
