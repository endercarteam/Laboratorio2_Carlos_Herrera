class Node:
    
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.edges = {}
    
    def add_edge(self, node, weight=0):
        self.edges[node] = weight
    
    def remove_edge(self, node):
        del self.edges[node]
