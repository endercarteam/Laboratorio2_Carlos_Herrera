import tkinter as tk
from tkinter import *
"""from PIL import Image, ImageTk"""
from Node import Node

from Graph import Graph
from Nodo import Nodo
from Arista import Arista
from Grafo import Grafo


class App:
    
    def __init__(self, master):
        self.master = master
        master.title('Graph Editor')
        
        self.graph = Graph()
        self.selected = None
        """
        image = ImageTk.PhotoImage(Image.open('imagenes/mapa.png'))
        """
        self.canvas = tk.Canvas(master, width=400, height=400)
        self.canvas.pack()
       
        self.canvas.bind('<Button-1>', self.on_click)
        self.canvas.bind('<B1-Motion>', self.on_drag)
        
        add_button = tk.Button(master, text='Add Node', command=self.add_node)
        add_button.pack(side='left')
        remove_button = tk.Button(master, text='Remove', command=self.remove)
        remove_button.pack(side='left')
        FW_button = tk.Button(master, text='Floyd-Warshal', command = self.Floyd_Warshal)
        FW_button.pack(side='left')
        
        self.weight_entry = tk.Entry(master)
        self.weight_entry.pack(side='left')
        
        self.draw()
        
    def draw(self):
        self.canvas.delete('all')
        self.graph.draw(self.canvas)
        
        if self.selected:
            self.canvas.create_oval(self.selected.x-13, self.selected.y-13, self.selected.x+13, self.selected.y+13, outline='red', width=2)
        
        self.master.after(100, self.draw)
    
    def on_click(self, event):
        for node in self.graph.nodes:
            if abs(node.x - event.x) < 10 and abs(node.y - event.y) < 10:
                if self.selected and node != self.selected:
                    self.selected.add_edge(node, int(self.weight_entry.get()))
                elif not self.selected:
                    self.selected = node
                else:
                    self.selected = None
                return
        if not self.selected:
            self.add_node(event)
    
    def on_drag(self, event):
        if self.selected:
            self.selected.x = event.x
            self.selected.y = event.y
    
    def add_node(self, event=None):
        
         
       
        
        

        node = Node(250, 250)
        
        self.graph.add_node(node)  
        
    
    def remove(self):
        if self.selected:
            self.graph.remove_node(self.selected)
            self.selected = None
    
    def Floyd_Warshal(self):
        Graph.add_nodes()


            





        
root = tk.Tk()
app = App(root)
root.mainloop()