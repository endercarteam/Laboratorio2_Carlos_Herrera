class Arista:
    def __init__(self, inicio, fin, peso=None):
        self.inicio = inicio
        self.fin = fin
        self.peso = peso

    def obtener_inicio(self):
        return self.inicio

    def obtener_fin(self):
        return self.fin

    def obtener_peso(self):
        return self.peso
